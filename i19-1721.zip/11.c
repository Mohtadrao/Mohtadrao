/*Muhammad Mohtad Younus*/
/*19I-1721*/
/*Bs(AI-K)*/

#include<stdio.h>
#include <string.h>


int PlainLines(char name[],int B[96],char D[96])
{
char i;
int C[96];

int count = 0;
int j=0;
i=32;
while(i!=127){
FILE *fptr = fopen(name, "r");

char ch = fgetc(fptr);
if(i==32)
{
while(ch!=EOF){
//printf("%c",ch);

ch=fgetc(fptr);}
}count=0;
while (ch != EOF)
{
if(ch==i){
count++;}
ch = fgetc(fptr);
}
//printf("%c=%d",i,count);
B[j]=count;
D[j]=i;
j++;
i++;
//printf("\n");
fclose(fptr);

ch='\0';}
for(int m=0;m<96;m++){
C[m]=B[m];
}

int n=96,x=0;
int a;	
char d;    
        for (x = 0; x < n; x++) 
        {
            for (int j = x + 1; j < n; j++) 
            {
                if (B[x] < B[j]) 
                {
                    a = B[x];
                    d = D[x];
                    B[x] = B[j];
                    D[x] = D[j];
                    B[j] = a;
                    D[j] = d;
                }
            }
        }

                        
     //   printf("The As arranged in descending order are given below\n");
 
      /*  for (x = 0; x < n; ++x) 
        {
            printf("%c=%d\n",D[x], B[x]);
        
}*/
}


int main(int argc, char *argv[]){
int A[100];
int B[100];
char C[100];
char D[100];
char L[100];
char i;
int E[96];

int count = 0;
int k=0;
i=32;
while(i!=127){
FILE *fptr = fopen(argv[1], "r");

char ch = fgetc(fptr);
if(i==32)
{
while(ch!=EOF){
//printf("%c",ch);

ch=fgetc(fptr);}
}count=0;
while (ch != EOF)
{
if(ch==i){
count++;}
ch = fgetc(fptr);
}
//printf("%c=%d",i,count);
A[k]=count;
C[k]=i;
k++;
i++;
//printf("\n");
fclose(fptr);

ch='\0';}
for(int m=0;m<96;m++){
E[m]=A[m];
}

int n=96,x=0;
int a;	
char d;       
        for (x = 0; x < n; x++) 
        {
            for (int k = x + 1; k < n; k++) 
            {
                if (A[x] < A[k]) 
                {
                    a = A[x];
                    d = C[x];
                    A[x] = A[k];
                    C[x] = C[k];
                    A[k] = a;
                    C[k] = d;
                }
            }
        }
PlainLines("big1.txt",B,D);
char j=32;

for(int x=0;j!=127;x++){
if(D[x]==j){
printf("%c",C[x]);
j++;
x=0;
}
}


printf("\n");
 















   }
